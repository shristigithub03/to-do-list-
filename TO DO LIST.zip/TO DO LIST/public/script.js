// DOM Elements
const taskInput = document.getElementById('taskInput');
const taskList = document.getElementById('taskList');
const emptyState = document.getElementById('emptyState');
const totalTasksEl = document.getElementById('totalTasks');
const completedTasksEl = document.getElementById('completedTasks');

// API Base URL
const API_BASE_URL = 'http://localhost:3000/api';

// Error handling
function handleError(error) {
  console.error('Error:', error);
  alert('An error occurred. Please try again.');
}

// Show loading state
function showLoading() {
  taskList.innerHTML = '<li class="loading">Loading tasks...</li>';
}

// Update task statistics
function updateStats(tasks) {
  const totalTasks = tasks.length;
  const completedTasks = tasks.filter(task => task.completed).length;
  
  totalTasksEl.textContent = `${totalTasks} ${totalTasks === 1 ? 'task' : 'tasks'}`;
  completedTasksEl.textContent = `${completedTasks} completed`;
  
  // Show/hide empty state
  if (totalTasks === 0) {
    emptyState.style.display = 'block';
  } else {
    emptyState.style.display = 'none';
  }
}

// Render tasks to the DOM
function renderTasks(tasks) {
  taskList.innerHTML = '';
  
  tasks.forEach(task => {
    const taskItem = document.createElement('li');
    taskItem.className = `task-item ${task.completed ? 'completed' : ''}`;
    taskItem.innerHTML = `
      <span class="task-text">${task.text}</span>
      <div class="task-actions">
        <button class="complete-btn" onclick="toggleComplete(${task.id})">
          <i class="fas fa-check"></i>
        </button>
        <button class="delete-btn" onclick="deleteTask(${task.id})">
          <i class="fas fa-trash"></i>
        </button>
      </div>
    `;
    taskList.appendChild(taskItem);
  });
  
  updateStats(tasks);
}

// Load tasks from server
async function loadTasks() {
  try {
    showLoading();
    const res = await fetch(`${API_BASE_URL}/tasks`);
    
    if (!res.ok) throw new Error('Failed to load tasks');
    
    const tasks = await res.json();
    renderTasks(tasks);
  } catch (error) {
    handleError(error);
  }
}

// Add new task
async function addTask() {
  const text = taskInput.value.trim();
  if (!text) return;

  try {
    const res = await fetch(`${API_BASE_URL}/tasks`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ text })
    });

    if (!res.ok) throw new Error('Failed to add task');

    taskInput.value = '';
    await loadTasks();
    taskInput.focus();
  } catch (error) {
    handleError(error);
  }
}

// Toggle task completion
async function toggleComplete(id) {
  try {
    const res = await fetch(`${API_BASE_URL}/tasks/${id}/toggle`, {
      method: 'PATCH'
    });

    if (!res.ok) throw new Error('Failed to update task');

    await loadTasks();
  } catch (error) {
    handleError(error);
  }
}

// Delete task
async function deleteTask(id) {
  if (!confirm('Are you sure you want to delete this task?')) return;

  try {
    const res = await fetch(`${API_BASE_URL}/tasks/${id}`, {
      method: 'DELETE'
    });

    if (!res.ok) throw new Error('Failed to delete task');

    await loadTasks();
  } catch (error) {
    handleError(error);
  }
}

// Initialize the app
document.addEventListener('DOMContentLoaded', () => {
  loadTasks();
  
  // Add task on Enter key
  taskInput.addEventListener('keypress', (e) => {
    if (e.key === 'Enter') addTask();
  });
});